#!/usr/bin/env python
# coding: utf-8

# In[2]:


import boto3


sqs = boto3.client("sqs")

sqs.list_queues()
sqs.send_message(
    QueueUrl='https://sqs.us-east-1.amazonaws.com/114204391493/749-cloud-init-test',
    MessageBody='hello_world',    
)


# In[ ]:




