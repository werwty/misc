#!/usr/bin/env python

import sys

import boto3


if __name__ == "__main__":
    sqs = boto3.client("sqs")

    with open(sys.argv[1], 'r') as f:
        message = f.read()
    sqs.send_message(
        QueueUrl='https://sqs.us-east-1.amazonaws.com/114204391493/749-cloud-init-test',
        MessageBody=message,
    )


